'In Thrust We Trust' is a Solid Booster Decal set for KSP, included are decals for the following:

- Thiakol logos
- ATK logos
- Orbital ATK logos
- Northrop Grumman old & new logos
- Cygnus & Antares logos
- United Space Alliance logo
- Aerojet logos
- OmegA logos
- SLS booster 'swooshes' (Provided courtesy of NoLifeJordan)
- 'Inert' & 'Loaded' booster decals
- Circular and square tracking dots
- Complex tracking decals (Provided courtesy of SpaceFace482)
- Currently 5 different sets of SRB markings, in black, white & both

Usage of Conformal Decals is recommended.

Credits: AmateurAstro, NoLifeJordan, SpaceFace482
