In Thrust We Trust
'ITWT' is a Solid Booster Decal set for KSP
Included are decals for the following:

- Thiakol logos
- ATK logos
- Orbital ATK logos
- Northrop Grumman old & new logos
- Cygnus & Antares logos
- United Space Alliance logo
- SLS booster 'swooshes' (Provided courtesy of NoLifeJordan)
- Currently 5 different sets of SRB markings, in black, white & both

Usage of Conformal Decals is recommended.

Credits: AmateurAstro, NoLifeJordan